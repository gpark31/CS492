#include <linux/syscalls.h>
#include <linux/string.h>
#include <linux/module.h>
#include <linux/init.h>

SYSCALL_DEFINE1(GaYoung_syscall, char __user *, s){
	int ssize;
	char buffer[32];
	long rCount = 0;
	int i;
	if( (ssize = strlen_user(s)) == 0){
		return -EFAULT;}
	if(s == NULL || ssize > 32){
		return -1;
	}
	if(strncpy_from_user(buffer, s, ssize) == -EFAULT){
		return -EFAULT;}
	printk(KERN_ALERT "before: %s\n", buffer);
	for(i = 0; i < ssize; i++){
		if(buffer[i] == 'a' || buffer[i] == 'e' || buffer[i] == 'i' || buffer[i] == 'o' || buffer[i] == 'u' || buffer[i] == 'y'){
			buffer[i] = 'X';
			rCount++;
		}
	}
	if(copy_to_user(s, buffer, ssize)){
		return -EFAULT;
	}
	printk(KERN_ALERT "after: %s\n", buffer);
	return rCount;
}
