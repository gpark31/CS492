#include <linux/module.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/fs_struct.h>

static int hello_init(void){
	printk(KERN_ALERT "Hello World from GaYoung (10446882)\n");
	return 0;
	}
static void hello_exit(void){
	printk(KERN_ALERT "PID: %d, Current Process: %s\n", current -> pid, current -> comm);
	}
module_init(hello_init);
module_exit(hello_exit);
MODULE_LICENSE("Dual BSD/GPL");
