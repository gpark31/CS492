#include <linux/kernel.h>
#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <stdlib.h>
#include <stdio.h>

long sys_call(char *s){
	return syscall(548, s);
}
int main(){
	char s[128] = "This string should not pass since this is longer than 32 characters";
	char pass[32] = "This string should pass";
	
	printf("Test String Before syscall: %s\n", s);
	long result1 = sys_call(s);
	printf("Returned: %ld\n", result1);
	printf("Test String After syscall: %s\n", s);

	printf("Test String Before syscall: %s\n", pass);
	long result2 = sys_call(pass);
	printf("Returned: %ld\n", result2);
	printf("Test String After syscall: %s\n", pass);

	return 0;
	}
